﻿using TheMovies.Models;

namespace TheMovies.Data.Interfaces
{
    internal interface ICinemaHallRepository : IBaseRepository<CinemaHall>
    {
    }
}
