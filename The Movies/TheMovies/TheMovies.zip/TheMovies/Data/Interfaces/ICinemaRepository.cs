﻿using TheMovies.Models;

namespace TheMovies.Data.Interfaces
{
    internal interface ICinemaRepository : IBaseRepository<Cinema>
    {
    }
}
