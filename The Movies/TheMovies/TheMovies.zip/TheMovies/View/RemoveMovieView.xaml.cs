﻿using System.Windows.Controls;

namespace TheMovies.View
{
    /// <summary>
    /// Interaction logic for RemoveMovieView.xaml
    /// </summary>
    public partial class RemoveMovieView : Page
    {
        public RemoveMovieView()
        {
            InitializeComponent();
        }
    }
}
