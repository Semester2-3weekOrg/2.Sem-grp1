﻿using System.Windows.Controls;
using TheMovies.ViewModels;

namespace TheMovies.View
{
    public partial class MainPageView : Page
    {

        public MainPageView()
        {
            InitializeComponent();
            DataContext = new MainViewModel();
        }


    }
}
